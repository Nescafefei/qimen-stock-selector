#!/usr/bin/env python3
import argparse
import csv
import json
from pathlib import Path
import pandas as pd

MONTH_ELEMENT = {
    1: '土月', 2: '木月', 3: '木月', 4: '土月', 5: '火月', 6: '火月',
    7: '土月', 8: '金月', 9: '金月', 10: '土月', 11: '水月', 12: '水月'
}
DAY_ELEMENT = {
    0: '水', 1: '木', 2: '木', 3: '火', 4: '火',
    5: '土', 6: '土', 7: '金', 8: '金', 9: '水'
}
NAME_COLS = ['stock_name', 'name', '股票名称', 'company']
SECTOR_COLS = ['sector', 'industry', '所属板块', '行业']
DATE_COLS = ['founding_date', 'established_date', '成立日期', 'ipo_date']


def pick_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None


def normalize_date(series):
    return pd.to_datetime(series, errors='coerce')


def forward_frame(df):
    name_col = pick_col(df, NAME_COLS)
    date_col = pick_col(df, DATE_COLS)
    if not date_col:
        raise ValueError('missing founding date column')
    dates = normalize_date(df[date_col])
    out = pd.DataFrame()
    out['stock_name'] = df[name_col] if name_col else ''
    out['founding_date'] = dates.dt.strftime('%Y-%m-%d')
    out['founding_year'] = dates.dt.year
    out['year_tail'] = dates.dt.year % 10
    out['founding_month'] = dates.dt.month
    out['month_element'] = dates.dt.month.map(MONTH_ELEMENT)
    out['founding_day'] = dates.dt.day
    out['day_tail'] = dates.dt.day % 10
    out['day_element'] = out['day_tail'].map(DAY_ELEMENT)
    out['quick_note'] = 'use these normalized fields for structure review and favorable-month inference'
    return out


def reverse_frame(df, sector, year_tail, pref_months, pref_days, annual_mainline=None, empty_penalty=False):
    name_col = pick_col(df, NAME_COLS)
    sector_col = pick_col(df, SECTOR_COLS)
    date_col = pick_col(df, DATE_COLS)
    if not date_col:
        raise ValueError('missing founding date column')
    dates = normalize_date(df[date_col])
    out = pd.DataFrame()
    out['stock_name'] = df[name_col] if name_col else ''
    out['sector'] = df[sector_col] if sector_col else ''
    out['founding_date'] = dates.dt.strftime('%Y-%m-%d')
    out['founding_year'] = dates.dt.year
    out['year_tail'] = dates.dt.year % 10
    out['founding_month'] = dates.dt.month
    out['month_element'] = dates.dt.month.map(MONTH_ELEMENT)
    out['founding_day'] = dates.dt.day
    out['day_tail'] = dates.dt.day % 10
    out['day_element'] = out['day_tail'].map(DAY_ELEMENT)

    pref_months_set = {x.strip() for x in pref_months.split(',') if x.strip()} if pref_months else set()
    pref_days_set = {x.strip() for x in pref_days.split(',') if x.strip()} if pref_days else set()
    annual_set = {x.strip() for x in annual_mainline.split(',') if x.strip()} if annual_mainline else set()

    out['sector_score'] = (out['sector'] == sector).astype(int) * 2 if sector else 0
    out['year_tail_score'] = (out['year_tail'] == year_tail).astype(int) * 2 if year_tail is not None else 0
    out['month_score'] = out['month_element'].isin(pref_months_set).astype(int) * 2 if pref_months_set else 0
    out['day_score'] = out['day_element'].isin(pref_days_set).astype(int) * 1 if pref_days_set else 0
    out['mainline_bonus'] = out['sector'].isin(annual_set).astype(int) * 1 if annual_set else 0
    out['empty_penalty'] = -1 if empty_penalty else 0
    out['auto_score'] = out[['sector_score', 'year_tail_score', 'month_score', 'day_score', 'mainline_bonus']].sum(axis=1) + out['empty_penalty']

    def priority(score):
        if score >= 9:
            return '优先'
        if score >= 6:
            return '次优'
        if score >= 3:
            return '观察'
        return '回避'

    def match_level(score):
        if score >= 9:
            return '匹配'
        if score >= 3:
            return '部分匹配'
        return '不匹配'

    out['priority'] = out['auto_score'].map(priority)
    out['match_level'] = out['auto_score'].map(match_level)
    out['note'] = 'needs manual deep review for structure fit, climate regulation, and flow/connection'
    out = out.sort_values(['auto_score', 'stock_name'], ascending=[False, True])
    return out


def read_table(path):
    path = Path(path)
    if path.suffix.lower() == '.csv':
        return pd.read_csv(path)
    if path.suffix.lower() in {'.xlsx', '.xls'}:
        return pd.read_excel(path)
    raise ValueError('input must be csv or xlsx/xls')


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='mode', required=True)

    p_f = sub.add_parser('forward')
    p_f.add_argument('--input', required=True)
    p_f.add_argument('--output', required=True)

    p_r = sub.add_parser('reverse')
    p_r.add_argument('--input', required=True)
    p_r.add_argument('--output', required=True)
    p_r.add_argument('--current-month', required=False)
    p_r.add_argument('--sector', required=False, default='')
    p_r.add_argument('--year-tail', type=int, required=False)
    p_r.add_argument('--preferred-month-elements', required=False, default='')
    p_r.add_argument('--preferred-day-elements', required=False, default='')
    p_r.add_argument('--annual-mainline', required=False, default='')
    p_r.add_argument('--empty-penalty', action='store_true')

    args = parser.parse_args()
    df = read_table(args.input)
    if args.mode == 'forward':
        out = forward_frame(df)
    else:
        out = reverse_frame(df, args.sector, args.year_tail, args.preferred_month_elements, args.preferred_day_elements, args.annual_mainline, args.empty_penalty)
        if args.current_month:
            out.insert(0, 'current_month', args.current_month)
    output = Path(args.output)
    if output.suffix.lower() == '.csv':
        out.to_csv(output, index=False)
    else:
        out.to_excel(output, index=False)
    print(f'wrote {output}')


if __name__ == '__main__':
    main()
