---
name: qimen-stock-analyzer
description: analyze qimen-based stock selection workflows for either (1) forward analysis from a company's founding date to infer likely favorable operating months, or (2) reverse screening from a current month setup to find companies whose sector, founding year tail, founding month, and founding day characteristics fit the user's qimen rules. use when the user wants single-stock judgment, batch csv/xlsx screening, a reusable scoring workflow, or a structured explanation that combines qimen outer screening with deeper destiny-structure review. trigger on stock screening, founding-date matching, qimen month rules, favorable months, or reverse selection from a month盘.
---

# Qimen Stock Analyzer

Use this skill for two modes.

1. **Forward mode**: company founding date -> structure notes -> likely favorable operating months.
2. **Reverse mode**: current month parameters -> candidate stock filter -> priority ranking.

## Workflow decision

- **If the user gives a company or founding date and asks what months fit it**: run **Forward workflow**.
- **If the user gives current month parameters and wants matching stocks**: run **Reverse workflow**.
- **If the user uploads CSV/XLSX**: run the batch script in `scripts/qimen_stock_tool.py` first, then interpret the results.

## Required inputs

### Forward mode
Collect these if missing:
- company name (optional but preferred)
- founding date in `YYYY-MM-DD` or `YYYY-MM-DD HH:MM`
- whether the user wants a **quick** or **full** explanation

### Reverse mode
Collect these if missing:
- current year branch context if the user is using annual direction rules
- current month label
- month gate / sector mapping
- value-symbol stem (临干)
- founding-year tail rule
- preferred founding-month element rule
- optional preferred founding-day element rule
- stock list, either inline or as CSV/XLSX

Do not assume a fixed calendar year or fixed month盘. Ask the user to provide the month parameters when they are not already in the conversation.

## Forward workflow

### Step 1: Normalize the founding date
Extract:
- founding year
- founding year tail digit
- founding month
- founding day
- founding month element using the simplified mapping in `references/qimen_rules.md`
- founding day element using the simplified day-tail mapping in `references/qimen_rules.md`

### Step 2: Build the structure review in layers
Use this order, matching the user's methodology:
1. four pillars if available
2. determine day master if available
3. inspect month command / environment
4. judge strength and balance
5. summarize ten-god structure tendency
6. identify the first need: strengthen, drain, regulate climate, or connect
7. infer useful elements and convert them into favorable months

If the full destiny structure cannot be strictly derived from the available data, be explicit that the result is a **research-oriented heuristic** rather than a strict traditional chart judgment.

### Step 3: Output two levels
Always provide both:
- a **quick conclusion**: favorable months / secondary months / avoid months
- a **reasoned explanation**: year-month interaction, structure tendency, first need, useful elements, month conversion

### Step 4: Use this output template

#### Quick result
- favorable months:
- secondary months:
- avoid months:

#### Why
- founding-year tendency:
- founding-month effect:
- structure tendency:
- first need:
- useful elements:
- month conversion:

## Reverse workflow

### Step 1: Apply qimen outer screening first
Always use this order:
1. annual direction rule -> determine yearly mainline sectors
2. current month gate -> determine monthly focus sector
3. 临干 -> determine founding-year tail filter
4. founding month rule -> determine preferred founding-month elements
5. optional founding-day rule -> determine extra score

This outer screen decides **who enters the pool**.

### Step 2: Batch filter or manual filter
- For CSV/XLSX, run `scripts/qimen_stock_tool.py reverse ...`.
- For a short inline list, you may score manually following `references/qimen_rules.md`.

### Step 3: Deep review only after outer screening
For top matches, do a second-layer review:
- whether founding month really balances founding year
- whether the simplified founding-day element helps or conflicts
- whether the current month is likely to activate the company's internal structure
- whether the stock should be labeled as `优先 / 次优 / 观察 / 回避`

### Step 4: Return two grading systems
Always include both:
- `优先 / 次优 / 观察 / 回避`
- `匹配 / 部分匹配 / 不匹配`

## Batch file handling

Use the script for CSV/XLSX files.

### Accepted stock columns
The script recognizes common aliases such as:
- stock name: `stock_name`, `name`, `股票名称`, `company`
- sector: `sector`, `industry`, `所属板块`, `行业`
- founding date: `founding_date`, `established_date`, `成立日期`, `ipo_date`

### Reverse batch command
```bash
python scripts/qimen_stock_tool.py reverse \
  --input stocks.xlsx \
  --output results.csv \
  --current-month "辛卯月" \
  --sector "车船物流" \
  --year-tail 9 \
  --preferred-month-elements "火月,土月" \
  --preferred-day-elements "火,土" \
  --annual-mainline "汽车,钢铁"
```

### Forward batch command
```bash
python scripts/qimen_stock_tool.py forward \
  --input stocks.xlsx \
  --output forward_results.csv
```

## Interpretation rules

- Treat annual rules and month-gate rules as **outer-screen conditions**.
- Treat founding month and founding day element fit as **secondary filters**.
- Treat deep structure review as **final selection**, not the first pass.
- If the user's data is incomplete, keep the answer explicit about what is rule-based vs heuristic.
- Never present the result as investment advice.

## References

- Use `references/qimen_rules.md` for mappings, scoring logic, and month/day element conversion.
- Use `references/output_templates.md` when formatting final explanations.

