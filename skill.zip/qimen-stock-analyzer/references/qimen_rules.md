# Qimen stock analyzer rules

## 1. Reverse workflow summary

Use this order:
1. annual branch decides yearly mainline sectors
2. current month gate decides monthly focus sector
3. current month stem decides founding-year tail
4. founding month decides whether the founding year is balanced
5. founding day gives a small extra score
6. deep structure review decides the final label

## 2. Founding-year tail mapping

- geng / 庚 -> 0
- xin / 辛 -> 1
- ren / 壬 -> 2
- gui / 癸 -> 3
- jia / 甲 -> 4
- yi / 乙 -> 5
- bing / 丙 -> 6
- ding / 丁 -> 7
- wu / 戊 -> 8
- ji / 己 -> 9

## 3. Simplified month element mapping

Use this simplified civil-month mapping unless the user supplies a stricter lunar/month-command mapping.

- 1 -> 土月
- 2 -> 木月
- 3 -> 木月
- 4 -> 土月
- 5 -> 火月
- 6 -> 火月
- 7 -> 土月
- 8 -> 金月
- 9 -> 金月
- 10 -> 土月
- 11 -> 水月
- 12 -> 水月

## 4. Simplified day-tail element mapping

- 1,2 -> 木
- 3,4 -> 火
- 5,6 -> 土
- 7,8 -> 金
- 9,0 -> 水

## 5. Forward heuristic

Use this sequence:
- founding date
- year tendency
- month environment
- strength / balance tendency
- structure note
- first need
- useful elements
- favorable months

If a strict traditional chart cannot be computed from available data, explicitly label the result as a heuristic structure review.

## 6. Reverse scoring

### Base automatic score
- sector match: 2
- founding-year-tail match: 2
- founding-month-element match: 2
- founding-day-element match: 1

### Optional manual review score
- structure fit with current month: +2 / +1 / 0 / -1
- climate regulation benefit: +2 / +1 / 0 / -1
- connection / flow benefit: +1 / 0 / -1
- empty / weak month penalty if user indicates it: -1

### Suggested labels
- 9+ => 优先 and 匹配
- 6-8 => 次优 and 部分匹配
- 3-5 => 观察 and 部分匹配
- 2 or below => 回避 and 不匹配

## 7. Annual and monthly rule usage

If the user provides an annual branch rule, apply it first.
If the user provides a monthly gate rule, apply it second.
Do not hardcode a specific year. Require the user to provide current month parameters unless already present in conversation.

## 8. Deep review checklist

For top candidates, check:
- whether founding month truly supports or balances founding year
- whether the current month helps or harms the candidate's likely structure
- whether the candidate belongs to the yearly mainline or only a side branch
- whether the result is suitable for `优先`, `次优`, `观察`, or `回避`

