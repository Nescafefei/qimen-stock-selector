# Output templates

## Forward single-company template

### Quick result
- company:
- founding date:
- favorable months:
- secondary months:
- avoid months:

### Structure explanation
- founding-year tendency:
- founding-month environment:
- likely structure tendency:
- first need:
- useful elements:
- month conversion:
- confidence note:

## Reverse screening template

### Current month setup
- annual direction:
- monthly gate sector:
- stem / year-tail rule:
- preferred founding-month elements:
- preferred founding-day elements:

### Screening result
| stock | sector | founding date | score | priority | match level | note |
|---|---|---|---:|---|---|---|

### Short explanation
- why these names entered the pool:
- what separates top candidates:
- what still needs manual deep review:

